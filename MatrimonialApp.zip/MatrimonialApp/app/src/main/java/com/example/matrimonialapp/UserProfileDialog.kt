package com.example.matrimonialapp

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import android.view.Gravity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
class UserProfileDialog(context: Context, private val user: UserModel) : Dialog(context) {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_user_profile)


        window?.setLayout(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.CENTER)

        val tvProfileName: TextView = findViewById(R.id.tvProfileName)
        val tvProfileAge: TextView = findViewById(R.id.tvProfileAge)
        val tvProfileLocation: TextView = findViewById(R.id.tvProfileLocation)
        val btnMessage: Button = findViewById(R.id.btnMessage)


        tvProfileName.text = "Name: ${user.name}"
        tvProfileAge.text = "Age: ${user.age}"
        tvProfileLocation.text = "Location: ${user.city}"


        btnMessage.setOnClickListener {
            if (!user.contact.isNullOrEmpty()) {
                openWhatsAppChat(user.contact)
            } else {
                Toast.makeText(context, "Error: Phone number not available!", Toast.LENGTH_SHORT).show()
            }
        }
    }



    private fun openWhatsAppChat(phoneNumber: String) {
        try {
            val formattedNumber = phoneNumber.replace(Regex("[^0-9]"), "")
            val uri = Uri.parse("https://wa.me/$formattedNumber")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.whatsapp")


            (context as? Activity)?.let {
                if (it.isFinishing) return
            }

            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Failed to open WhatsApp", Toast.LENGTH_SHORT).show()
        }
    }
}
