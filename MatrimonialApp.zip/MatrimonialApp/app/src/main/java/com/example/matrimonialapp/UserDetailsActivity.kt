package com.example.matrimonialapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.example.matrimonialapp.databinding.ActivityUserDetailsBinding
import com.example.matrimonialapp.utils.HeartView

class UserDetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityUserDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        binding = ActivityUserDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val heartView: HeartView = findViewById(R.id.heartView)
        heartView.bringToFront()


        val userId = intent.getStringExtra("USER_ID")
        val name = intent.getStringExtra("NAME") ?: "Unknown"
        val age = intent.getIntExtra("AGE", 0)
        val gender = intent.getStringExtra("GENDER") ?: "Unknown"
        val phoneNumber = intent.getStringExtra("CONTACT") ?: ""

        Log.d("UserDetailsDebug", "Opened profile: ID=$userId, Name=$name, Age=$age, Gender=$gender, Phone=$phoneNumber")


        binding.tvUserName.text = name
        binding.tvUserAge.text = "Age: $age"
        binding.tvUserGender.text = "Gender: $gender"
        binding.tvUsercontact.text = "Phone: $phoneNumber"


        binding.btnChatWhatsapp.setOnClickListener {
            openWhatsApp(phoneNumber)
        }


        val animation = AnimationUtils.loadAnimation(this, R.anim.floating_heart)
        binding.heart1.startAnimation(animation)
        binding.heart2.startAnimation(animation)
        binding.heart3.startAnimation(animation)


        if (userId != null) {
            fetchUserDetails(userId)
        }
    }

    private fun openWhatsApp(phoneNumber: String) {
        if (phoneNumber.isNotEmpty()) {
            val uri = Uri.parse("https://wa.me/$phoneNumber")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }
    }

    private fun fetchUserDetails(userId: String) {

        Log.d("UserDetailsDebug", "Fetching details for user: $userId")
    }
}
