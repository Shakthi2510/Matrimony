package com.example.matrimonialapp

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.matrimonialapp.databinding.ItemMatchBinding

class MatchAdapter(
    private var userList: List<User>,
    private val onInterestedClick: (User) -> Unit,
    private val onUserClick: (User) -> Unit
) : RecyclerView.Adapter<MatchAdapter.MatchViewHolder>() {

    class MatchViewHolder(val binding: ItemMatchBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MatchViewHolder {
        val binding = ItemMatchBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MatchViewHolder(binding)

    }

    override fun onBindViewHolder(holder: MatchViewHolder, position: Int) {
        val user = userList[position]
        holder.binding.matchName.text = user.name
        holder.binding.matchAge.text = "Age: ${user.age}"

        holder.binding.btnInterested.setOnClickListener { onInterestedClick(user) }
        holder.binding.btnNotInterested.setOnClickListener { removeItem(position) }
        holder.itemView.setOnClickListener { onUserClick(user) }
    }

    override fun getItemCount(): Int = userList.size

    fun updateList(newList: List<User>) {
        userList = newList
        notifyDataSetChanged()
    }

    private fun removeItem(position: Int) {
        userList = userList.toMutableList().apply { removeAt(position) }
        notifyItemRemoved(position)
    }

    private fun decodeBase64(base64Str: String?): Bitmap? {
        return try {
            val decodedBytes = Base64.decode(base64Str, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
        } catch (e: Exception) {
            null
        }
    }
}
