package com.example.matrimonialapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.matrimonialapp.utils.HeartView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class NotificationSettingsActivity : AppCompatActivity() {

    private lateinit var switchMessages: Switch
    private lateinit var switchMatches: Switch
    private lateinit var btnSaveNotifications: Button
    private val db = FirebaseFirestore.getInstance()
    private val userId = FirebaseAuth.getInstance().currentUser?.uid

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification_settings)

        switchMessages = findViewById(R.id.switchMessages)
        switchMatches = findViewById(R.id.switchMatches)
        btnSaveNotifications = findViewById(R.id.btnSaveNotifications)
        val heartView: HeartView = findViewById(R.id.heartView)
        heartView.bringToFront()

        loadNotificationSettings()

        btnSaveNotifications.setOnClickListener {
            saveNotificationSettings()
        }
    }

    private fun loadNotificationSettings() {
        userId?.let {
            db.collection("users").document(it).get().addOnSuccessListener { document ->
                if (document.exists()) {
                    switchMessages.isChecked = document.getBoolean("messageNotifications") ?: true
                    switchMatches.isChecked = document.getBoolean("matchNotifications") ?: true
                }
            }
        }
    }

    private fun saveNotificationSettings() {
        val preferences: Map<String, Any> = mapOf(
            "messageNotifications" to switchMessages.isChecked,
            "matchNotifications" to switchMatches.isChecked
        )

        userId?.let {
            db.collection("users").document(it).update(preferences).addOnSuccessListener {
                Toast.makeText(this, "Notification Preferences Updated", Toast.LENGTH_SHORT).show()
            }
        }
    }

}
