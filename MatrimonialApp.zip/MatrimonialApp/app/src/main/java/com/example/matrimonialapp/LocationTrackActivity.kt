package com.example.matrimonialapp.activities

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.matrimonialapp.R
import com.example.matrimonialapp.UserDetailsActivity
import com.example.matrimonialapp.utils.HeartView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay

class LocationTrackActivity : AppCompatActivity() {

    private lateinit var mapView: MapView
    private lateinit var locationOverlay: MyLocationNewOverlay
    private lateinit var database: DatabaseReference
    private val markers = mutableMapOf<String, Marker>()

    private val LOCATION_PERMISSION_REQUEST_CODE = 1
    private val NOTIFICATION_CHANNEL_ID = "nearby_user_alerts"
    private var currentUserId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_location_track)


        val firebaseUser = FirebaseAuth.getInstance().currentUser
        currentUserId = firebaseUser?.uid ?: return

        database = FirebaseDatabase.getInstance().getReference("users")


        if (!checkLocationPermission()) {
            requestLocationPermission()
        }


        Configuration.getInstance().userAgentValue = packageName
        mapView = findViewById(R.id.mapView)
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)

        locationOverlay = MyLocationNewOverlay(GpsMyLocationProvider(this), mapView)
        locationOverlay.enableMyLocation()
        locationOverlay.enableFollowLocation()
        mapView.overlays.add(locationOverlay)

        mapView.controller.setZoom(18.0)

        createNotificationChannel()
        fetchAndStoreUserDetails()
        startLocationUpdates()
        listenForAllUsers()
    }

    private fun checkLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestLocationPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ),
            LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    private fun fetchAndStoreUserDetails() {
        val userRef = database.child(currentUserId)
        userRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val name = snapshot.child("name").getValue(String::class.java) ?: "Unknown"
                val age = snapshot.child("age").getValue(Int::class.java) ?: 0
                val gender = snapshot.child("gender").getValue(String::class.java) ?: "Unknown"
                val contact = snapshot.child("contact").getValue(String::class.java) ?: "N/A"

                Log.d("FirebaseDebug", "Fetched: Name=$name, Age=$age, Gender=$gender, Contact=$contact")

                val userData = mutableMapOf<String, Any>()
                if (snapshot.child("name").value == null) userData["name"] = name
                if (snapshot.child("age").value == null) userData["age"] = age
                if (snapshot.child("gender").value == null) userData["gender"] = gender
                if (snapshot.child("contact").value == null) userData["contact"] = contact

                if (userData.isNotEmpty()) {
                    userRef.updateChildren(userData)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("FirebaseError", error.message)
            }
        })
    }

    private fun startLocationUpdates() {
        if (!checkLocationPermission()) return

        val updateInterval = 1000L

        val locationUpdateRunnable = object : Runnable {
            override fun run() {
                val myLocation = locationOverlay.myLocation
                if (myLocation != null) {
                    val userData = mapOf(
                        "latitude" to myLocation.latitude,
                        "longitude" to myLocation.longitude
                    )
                    database.child(currentUserId).updateChildren(userData)
                }
                mapView.postDelayed(this, updateInterval)
            }
        }

        mapView.post(locationUpdateRunnable)
    }

    private fun listenForAllUsers() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!checkLocationPermission()) return

                val myLocation = locationOverlay.myLocation ?: return

                for (userSnapshot in snapshot.children) {
                    val userId = userSnapshot.key ?: continue
                    if (userId == currentUserId) continue

                    val latitude = userSnapshot.child("latitude").getValue(Double::class.java) ?: continue
                    val longitude = userSnapshot.child("longitude").getValue(Double::class.java) ?: continue
                    val name = userSnapshot.child("name").getValue(String::class.java) ?: "Unknown"
                    val age = userSnapshot.child("age").getValue(Int::class.java) ?: 0
                    val gender = userSnapshot.child("gender").getValue(String::class.java) ?: "Unknown"
                    val contact = userSnapshot.child("contact").getValue(String::class.java) ?: "N/A"

                    updateUserMarker(userId, latitude, longitude, name, age, gender, contact)

                    val userLocation = Location("").apply {
                        this.latitude = latitude
                        this.longitude = longitude
                    }

                    val myLoc = Location("").apply {
                        this.latitude = myLocation.latitude
                        this.longitude = myLocation.longitude
                    }

                    val distance = myLoc.distanceTo(userLocation)

                    if (distance < 10) {
                        sendNotification(name, age, gender, contact, userId)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("FirebaseError", error.message)
            }
        })
    }

    private fun updateUserMarker(userId: String, latitude: Double, longitude: Double, name: String, age: Int, gender: String, contact: String) {
        runOnUiThread {
            val geoPoint = GeoPoint(latitude, longitude)

            if (markers.containsKey(userId)) {
                markers[userId]?.position = geoPoint
            } else {
                val marker = Marker(mapView).apply {
                    icon = ContextCompat.getDrawable(this@LocationTrackActivity, R.drawable.ic_location)
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    title = "$name, $age, $gender, Contact: $contact"
                }
                marker.position = geoPoint
                markers[userId] = marker
                mapView.overlays.add(marker)
            }
            mapView.invalidate()
        }
    }

    private fun sendNotification(name: String, age: Int, gender: String, contact: String, userId: String) {
        val intent = Intent(this, UserDetailsActivity::class.java).apply {
            putExtra("USER_ID", userId)
            putExtra("NAME", name)
            putExtra("AGE", age)
            putExtra("GENDER", gender)
            putExtra("CONTACT", contact)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            this, userId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_heart)
            .setContentTitle("New User Nearby!")
            .setContentText("$name ($age, $gender) is near you. Tap to view profile.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(this).notify(userId.hashCode(), notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID, "Nearby User Alerts",
                NotificationManager.IMPORTANCE_HIGH
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }
}
