package com.example.matrimonialapp

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.matrimonialapp.utils.HeartView
import com.example.matrimonyapp.activities.LoginActivity
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class PrivacySettingsActivity : AppCompatActivity() {

    private lateinit var checkProfileVisibility: CheckBox
    private lateinit var btnDeleteAccount: Button
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val userId = auth.currentUser?.uid

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_privacy_settings)

        checkProfileVisibility = findViewById(R.id.checkProfileVisibility)
        btnDeleteAccount = findViewById(R.id.btnDeleteAccount)
        val heartView: HeartView = findViewById(R.id.heartView)
        heartView.bringToFront()

        loadPrivacySettings()

        checkProfileVisibility.setOnCheckedChangeListener { _, isChecked ->
            updateProfileVisibility(isChecked)
        }

        btnDeleteAccount.setOnClickListener {
            confirmDeleteAccount()
        }
    }

    private fun loadPrivacySettings() {
        userId?.let {
            db.collection("users").document(it).get().addOnSuccessListener { document ->
                if (document.exists()) {
                    checkProfileVisibility.isChecked = document.getBoolean("profileVisible") ?: true
                }
            }
        }
    }

    private fun updateProfileVisibility(isVisible: Boolean) {
        userId?.let {
            db.collection("users").document(it).update("profileVisible", isVisible)
                .addOnSuccessListener {
                    Toast.makeText(this, "Privacy Settings Updated", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun confirmDeleteAccount() {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Delete Account")
            .setMessage("Are you sure you want to delete your account? This action cannot be undone.")
            .setPositiveButton("Delete") { _, _ -> reAuthenticateAndDeleteAccount() }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    private fun reAuthenticateAndDeleteAccount() {
        val user = auth.currentUser
        if (user != null && user.email != null) {
            val passwordInput = EditText(this)
            passwordInput.hint = "Enter your password"

            AlertDialog.Builder(this)
                .setTitle("Re-Authenticate")
                .setMessage("Please enter your password to delete your account.")
                .setView(passwordInput)
                .setPositiveButton("Confirm") { _, _ ->
                    val password = passwordInput.text.toString()
                    if (password.isNotEmpty()) {
                        val credential = EmailAuthProvider.getCredential(user.email!!, password)
                        user.reauthenticate(credential).addOnSuccessListener {
                            deleteAccount()
                        }.addOnFailureListener {
                            Toast.makeText(this, "Authentication Failed", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this, "Password cannot be empty", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun deleteAccount() {
        userId?.let { uid ->
            db.collection("users").document(uid).delete().addOnSuccessListener {
                auth.currentUser?.let { user ->
                    user.delete()
                        .addOnSuccessListener {
                            Toast.makeText(this, "Account Deleted", Toast.LENGTH_SHORT).show()
                            startActivity(Intent(this, LoginActivity::class.java))
                            finish()
                        }
                        .addOnFailureListener { e ->
                            Toast.makeText(this, "Failed to delete account: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                } ?: Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show()
            }.addOnFailureListener { e ->
                Toast.makeText(this, "Failed to delete user data: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

}
