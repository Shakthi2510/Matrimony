package com.example.matrimonialapp

import android.content.Intent
import android.graphics.drawable.AnimationDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.matrimonialapp.utils.HeartView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class GreatMatchActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private val matchList = mutableListOf<Users>()
    private var currentIndex = 0

    private lateinit var tvName: TextView
    private lateinit var tvAge: TextView
    private lateinit var tvLocation: TextView
    private lateinit var btnInterested: Button
    private lateinit var btnNotInterested: Button
    private lateinit var imgHeartEffect: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_great_match)

        val heartView: HeartView = findViewById(R.id.heartView)
        heartView.bringToFront()


        tvName = findViewById(R.id.tvName)
        tvAge = findViewById(R.id.tvAge)
        tvLocation = findViewById(R.id.tvLocation)
        btnInterested = findViewById(R.id.btnInterested)
        btnNotInterested = findViewById(R.id.btnNotInterested)
        imgHeartEffect = findViewById(R.id.imgHeartEffect)


        btnInterested.setOnClickListener { onInterestedClicked() }
        btnNotInterested.setOnClickListener { onNotInterestedClicked() }


        getCurrentUserDetails()
    }

    private fun getCurrentUserDetails() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        userId?.let {
            db.collection("users").document(it).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val gender = document.getString("gender")
                        fetchMatches(gender)
                    }
                }
                .addOnFailureListener { e -> Log.e("Firebase", "Error fetching user", e) }
        }
    }

    private fun fetchMatches(currentGender: String?) {
        db.collection("users").get()
            .addOnSuccessListener { documents ->
                matchList.clear()
                for (document in documents) {
                    val gender = document.getString("gender") ?: ""
                    if ((currentGender == "Male" && gender == "Female") ||
                        (currentGender == "Female" && gender == "Male")) {

                        matchList.add(
                            Users(
                                userId = document.id,
                                name = document.getString("name") ?: "",
                                age = document.getLong("age")?.toInt() ?: 0,
                                city = document.getString("city") ?: ""
                            )
                        )
                    }
                }
                showNextProfile()
            }
            .addOnFailureListener { e -> Log.e("Firebase", "Error fetching matches", e) }
    }

    private fun showNextProfile() {
        if (currentIndex < matchList.size) {
            val user = matchList[currentIndex]


            tvName.animate().alpha(0f).setDuration(200).withEndAction {
                tvName.text = user.name
                tvAge.text = "Age: ${user.age}"
                tvLocation.text = "Location: ${user.city}"
                tvName.animate().alpha(1f).setDuration(200).start()
            }.start()
        } else {
            finish()
        }
    }

    private fun onNotInterestedClicked() {
        playHeartAnimation(R.drawable.broken_heart_anim)
        currentIndex++
        if (currentIndex < matchList.size) {
            showNextProfile()
        } else {
            finish()
        }
    }

    private fun onInterestedClicked() {
        playHeartAnimation(R.drawable.double_heart_anim)

        if (currentIndex < matchList.size) {
            val user = matchList[currentIndex]


            imgHeartEffect.postDelayed({
                val intent = Intent(this, UserProfileActivity::class.java)
                intent.putExtra("userId", user.userId)
                startActivity(intent)
            }, 5000)
        }
    }

    private fun playHeartAnimation(animationRes: Int) {
        imgHeartEffect.setBackgroundResource(animationRes)
        val anim = imgHeartEffect.background as AnimationDrawable

        imgHeartEffect.alpha = 0f
        imgHeartEffect.visibility = View.VISIBLE


        imgHeartEffect.animate().alpha(1f).setDuration(300).withEndAction {
            anim.start()
        }.start()


        imgHeartEffect.postDelayed({
            imgHeartEffect.animate().alpha(0f).setDuration(500).withEndAction {
                anim.stop()
                imgHeartEffect.visibility = View.INVISIBLE
            }.start()
        }, 3000)
    }
}

data class Users(
    val userId: String,
    val name: String,
    val age: Int,
    val city: String
)
