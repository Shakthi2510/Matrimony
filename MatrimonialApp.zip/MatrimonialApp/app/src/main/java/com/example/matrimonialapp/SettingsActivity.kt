package com.example.matrimonialapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.matrimonialapp.utils.HeartView
import com.example.matrimonyapp.activities.LoginActivity
import com.google.firebase.auth.FirebaseAuth

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val btnProfileSettings: Button = findViewById(R.id.btnProfileSettings)
        val btnNotificationSettings: Button = findViewById(R.id.btnNotificationSettings)
        val btnPrivacySettings: Button = findViewById(R.id.btnPrivacySettings)
        val btnLogout: Button = findViewById(R.id.btnLogout)
        val heartView: HeartView = findViewById(R.id.heartView)
        heartView.bringToFront()


        btnProfileSettings.setOnClickListener {
            startActivity(Intent(this, ExtraDetailsActivity::class.java))
        }


        btnNotificationSettings.setOnClickListener {
            startActivity(Intent(this, NotificationSettingsActivity::class.java))
        }


        btnPrivacySettings.setOnClickListener {
            startActivity(Intent(this, PrivacySettingsActivity::class.java))
        }


        btnLogout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
