package com.example.matrimonialapp

import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.matrimonialapp.utils.HeartView
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.io.ByteArrayOutputStream
import java.io.InputStream

class ExtraDetailsActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var progressDialog: ProgressDialog
    private var base64Image: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_extra_details)

        val heartView: HeartView = findViewById(R.id.heartView)
        heartView.bringToFront()

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        progressDialog = ProgressDialog(this)

        val nameEditText = findViewById<EditText>(R.id.editTextName)
        val ageEditText = findViewById<EditText>(R.id.editTextAge)
        val cityEditText = findViewById<EditText>(R.id.editTextCity)
        val genderDropdown = findViewById<MaterialAutoCompleteTextView>(R.id.spinnerGender)
        val jobEditText = findViewById<EditText>(R.id.editTextJob)
        val educationEditText = findViewById<EditText>(R.id.editTextEducation)
        val interestsEditText = findViewById<EditText>(R.id.editTextInterests)
        val contactEditText = findViewById<EditText>(R.id.editTextContact)
        val saveButton = findViewById<Button>(R.id.buttonSave)

        val genderOptions = listOf("Male", "Female", "Other")
        val genderAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, genderOptions)
        genderDropdown.setAdapter(genderAdapter)

        genderDropdown.setOnItemClickListener { parent, view, position, id ->
            val selected = parent.getItemAtPosition(position).toString()
            Toast.makeText(this, "Selected: $selected", Toast.LENGTH_SHORT).show()
        }

        saveButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val ageStr = ageEditText.text.toString().trim()
            val city = cityEditText.text.toString().trim()
            val gender = genderDropdown.text.toString().trim()
            val job = jobEditText.text.toString().trim()
            val education = educationEditText.text.toString().trim()
            val interests = interestsEditText.text.toString().trim()
            val contact = contactEditText.text.toString().trim()

            if (name.isEmpty() || ageStr.isEmpty() || city.isEmpty()) {
                Toast.makeText(this, "Please fill all required fields!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (gender.isEmpty() || !genderOptions.contains(gender)) {
                Toast.makeText(this, "Please select a valid gender!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val age = ageStr.toIntOrNull()
            if (age == null || age <= 0) {
                Toast.makeText(this, "Enter a valid age!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val userId = auth.currentUser?.uid
            if (userId == null) {
                Toast.makeText(this, "User not logged in!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!isNetworkAvailable()) {
                Toast.makeText(this, "No Internet Connection!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            progressDialog.setMessage("Saving Profile...")
            progressDialog.setCancelable(false)
            progressDialog.show()

            saveUserData(userId, name, age, city, gender, job, education, interests, contact, base64Image)
        }
    }

    private fun saveUserData(
        userId: String,
        name: String,
        age: Int,
        city: String,
        gender: String,
        job: String,
        education: String,
        interests: String,
        contact: String,
        profileImageBase64: String?
    ) {
        val user = hashMapOf(
            "name" to name,
            "age" to age,
            "gender" to gender,
            "city" to city,
            "latitude" to 0.0,
            "longitude" to 0.0,
            "job" to job,
            "education" to education,
            "interests" to interests,
            "contact" to contact,
            "profileImage" to (profileImageBase64 ?: "")
        )

        db.collection("users").document(userId).set(user)
            .addOnSuccessListener {
                progressDialog.dismiss()
                Toast.makeText(this, "Profile Updated Successfully!", Toast.LENGTH_SHORT).show()
                setResult(Activity.RESULT_OK, Intent())
                finish()
            }
            .addOnFailureListener {
                progressDialog.dismiss()
                Toast.makeText(this, "Failed to update profile!", Toast.LENGTH_SHORT).show()
            }
    }

    private fun convertToBase64(uri: Uri) {
        try {
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            val byteArrayOutputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream)
            val byteArray = byteArrayOutputStream.toByteArray()
            base64Image = Base64.encodeToString(byteArray, Base64.DEFAULT)
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to convert image!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return connectivityManager.activeNetworkInfo?.isConnectedOrConnecting == true
    }
}
