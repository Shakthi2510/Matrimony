package com.example.matrimonialapp

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.matrimonialapp.utils.HeartView
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

class MapActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)


        webView = findViewById(R.id.mapWebView)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        setupWebView()
        requestLocation()
        getFCMToken()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webSettings: WebSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()
    }

    private fun requestLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
            return
        }

        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val latitude = location.latitude
                val longitude = location.longitude

                val userId = auth.currentUser?.uid ?: return@addOnSuccessListener
                val userLocation = hashMapOf(
                    "lat" to latitude,
                    "lon" to longitude
                )

                firestore.collection("users").document(userId)
                    .set(userLocation)

                webView.loadUrl("file:///android_asset/map.html?lat=$latitude&lon=$longitude")

                findMatches(userId, latitude, longitude)
            }
        }
    }

    private fun findMatches(userId: String, userLat: Double, userLon: Double) {
        firestore.collection("users").get().addOnSuccessListener { result ->
            for (document in result) {
                val data = document.data
                val lat = data["lat"] as? Double ?: continue
                val lon = data["lon"] as? Double ?: continue
                val otherUserId = document.id

                if (otherUserId != userId && getDistance(userLat, userLon, lat, lon) <= 10) {
                    sendNotification(otherUserId, "Match Found!", "A nearby user has matched with you!")
                }
            }
        }
    }

    private fun getDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val R = 6371
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return R * c
    }

    private fun sendNotification(userId: String, title: String, message: String) {
        firestore.collection("users").document(userId).get().addOnSuccessListener { document ->
            val token = document.getString("fcmToken") ?: return@addOnSuccessListener

            val json = JSONObject().apply {
                put("to", token)
                put("notification", JSONObject().apply {
                    put("title", title)
                    put("body", message)
                })
            }

            val requestBody = json.toString().toRequestBody("application/json".toMediaType())

            val client = OkHttpClient()
            val request = Request.Builder()
                .url("https://fcm.googleapis.com/fcm/send")
                .post(requestBody)
                .addHeader("Authorization", "key=YOUR_FIREBASE_SERVER_KEY")
                .addHeader("Content-Type", "application/json")
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    Log.e("FCM", "Notification failed: ${e.message}")
                }

                override fun onResponse(call: Call, response: Response) {
                    Log.d("FCM", "Notification sent successfully")
                }
            })
        }
    }

    private fun getFCMToken() {
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            val userId = auth.currentUser?.uid ?: return@addOnSuccessListener
            firestore.collection("users").document(userId).update("fcmToken", token)
        }
    }
}
