package com.example.matrimonialapp

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.matrimonyapp.activities.MainActivity

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val backgroundImage = findViewById<ImageView>(R.id.backgroundImage)


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {

            backgroundImage.setRenderEffect(RenderEffect.createBlurEffect(25f, 25f, Shader.TileMode.CLAMP))
        } else {

            backgroundImage.post {
                val bitmap = (backgroundImage.drawable as BitmapDrawable).bitmap
                backgroundImage.setImageBitmap(blurBitmap(bitmap, 10f))
            }
        }

        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }, 3000)
    }

    private fun blurBitmap(bitmap: Bitmap, radius: Float): Bitmap {
        // TODO: Implement blur effect for older Android versions
        return bitmap
    }
}
