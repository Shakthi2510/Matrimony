package com.example.matrimonialapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.matrimonialapp.adapters.UserAdapter
import com.example.matrimonialapp.utils.HeartView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class UserSelectionActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private val userList = mutableListOf<UserModel>()
    private lateinit var adapter: UserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_selection)
        val heartView: HeartView = findViewById(R.id.heartView)
        heartView.bringToFront()

        recyclerView = findViewById(R.id.recyclerViewUsers)


        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = UserAdapter(this, userList) { position ->
            userList.removeAt(position)
            adapter.notifyItemRemoved(position)
            adapter.notifyItemRangeChanged(position, userList.size)
            Toast.makeText(this, "User removed", Toast.LENGTH_SHORT).show()
        }
        recyclerView.adapter = adapter

        fetchUsers()
    }

    private fun fetchUsers() {
        val currentUserId = FirebaseAuth.getInstance().currentUser?.uid

        FirebaseFirestore.getInstance().collection("users")
            .get()
            .addOnSuccessListener { documents ->
                userList.clear()
                for (doc in documents) {
                    val userId = doc.id
                    if (userId != currentUserId) {
                        val name = doc.getString("name") ?: "Unknown"
                        val age = doc.getLong("age")?.toInt() ?: 0
                        val location = doc.getString("location") ?: "Unknown"

                        userList.add(UserModel(userId, name, age, location))
                    }
                }

                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to load users", Toast.LENGTH_SHORT).show()
            }
    }
}
