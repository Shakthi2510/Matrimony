package com.example.matrimonialapp

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.matrimonialapp.utils.HeartView
import com.google.firebase.firestore.FirebaseFirestore

class ViewDetailsActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var profileImageView: ImageView
    private lateinit var nameTextView: TextView
    private lateinit var ageTextView: TextView
    private lateinit var genderTextView: TextView
    private lateinit var locationTextView: TextView
    private lateinit var jobTextView: TextView
    private lateinit var educationTextView: TextView
    private lateinit var interestsTextView: TextView
    private lateinit var contactTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_details)
        val heartView: HeartView = findViewById(R.id.heartView)
        heartView.bringToFront()

        db = FirebaseFirestore.getInstance()


        nameTextView = findViewById(R.id.nameTextView)
        ageTextView = findViewById(R.id.ageTextView)
        genderTextView = findViewById(R.id.genderTextView)
        locationTextView = findViewById(R.id.locationTextView)
        jobTextView = findViewById(R.id.jobTextView)
        educationTextView = findViewById(R.id.educationTextView)
        interestsTextView = findViewById(R.id.interestsTextView)
        contactTextView = findViewById(R.id.contactTextView)

        val userId = intent.getStringExtra("userId")
        if (!userId.isNullOrEmpty()) {
            loadUserDetails(userId)
        } else {
            Toast.makeText(this, "User ID not found!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun loadUserDetails(userId: String) {
        db.collection("users").document(userId).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    nameTextView.text = "Name: " + (document.getString("name") ?: "N/A")
                    ageTextView.text = "Age: " + (document.getString("age") ?: "N/A")
                    genderTextView.text = "Gender: " + (document.getString("gender") ?: "N/A")
                    locationTextView.text = "Location: " + (document.getString("location") ?: "N/A")
                    jobTextView.text = "Job: " + (document.getString("job") ?: "N/A")
                    educationTextView.text =
                        "Education: " + (document.getString("education") ?: "N/A")
                    interestsTextView.text =
                        "Interests: " + (document.getString("interests") ?: "N/A")
                    contactTextView.text = "Contact: " + (document.getString("contact") ?: "N/A")

                    val profileImageBase64 = document.getString("profileImageBase64")
                    if (!profileImageBase64.isNullOrEmpty()) {
                        val bitmap = decodeBase64ToBitmap(profileImageBase64)
                        runOnUiThread {
                            if (bitmap != null) {
                                profileImageView.setImageBitmap(bitmap)
                            } else {
                                profileImageView.setImageResource(R.drawable.default_profile)
                            }
                        }
                    } else {
                        profileImageView.setImageResource(R.drawable.default_profile)
                    }
                } else {
                    Toast.makeText(this, "User details not found!", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error loading details", Toast.LENGTH_SHORT).show()
            }
    }

    private fun decodeBase64ToBitmap(base64String: String?): Bitmap? {
        if (base64String.isNullOrEmpty()) {
            Log.e("Base64Decode", "Base64 string is empty or null.")
            return null
        }

        return try {

            val cleanedBase64 = base64String.replace("^data:image/[^;]+;base64,".toRegex(), "")


            val decodedBytes = Base64.decode(cleanedBase64, Base64.DEFAULT)


            if (decodedBytes.isEmpty()) {
                Log.e("Base64Decode", "Decoded byte array is empty!")
                return null
            }


            val options = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }

            BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size, options)
        } catch (e: IllegalArgumentException) {
            Log.e("Base64Decode", "Invalid Base64 input: ${e.message}")
            null
        } catch (e: Exception) {
            Log.e("Base64Decode", "Error decoding Base64: ${e.message}")
            null
        }
    }
}
