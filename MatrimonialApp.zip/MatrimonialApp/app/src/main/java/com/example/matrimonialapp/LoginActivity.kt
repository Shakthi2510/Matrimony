package com.example.matrimonyapp.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.matrimonialapp.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var auth: FirebaseAuth
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        binding.btnLogin.setOnClickListener {
            val email = binding.etEmail.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                showToast("Please enter both email and password")
                return@setOnClickListener
            }

            loginUser(email, password)
        }

        binding.tvSignup.setOnClickListener {
            startActivity(Intent(this, com.example.matrimonialapp.RegisterActivity::class.java))
        }
    }

    private fun loginUser(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    user?.let {
                        val uid = it.uid
                        Log.d("FirebaseAuth", "User authenticated: UID: $uid")
                        checkUserInFirestore(uid, email)
                    }
                } else {
                    val errorMessage = task.exception?.localizedMessage ?: "Login Failed!"
                    Log.e("FirebaseAuth", "Login failed: $errorMessage")
                    showToast(errorMessage)
                }
            }
    }

    private fun checkUserInFirestore(uid: String, email: String) {
        val userRef = db.collection("users").document(uid)

        userRef.get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    Log.d("Firestore", "User found in Firestore with UID: $uid")
                    navigateToHome()
                } else {
                    Log.w("Firestore", "User UID not found. Checking by email...")

                    db.collection("users").whereEqualTo("email", email).get()
                        .addOnSuccessListener { querySnapshot ->
                            if (!querySnapshot.isEmpty) {
                                Log.d("Firestore", "User found using email: $email")
                                navigateToHome()
                            } else {
                                Log.e("Firestore", "User not found in Firestore. Adding user...")
                                addUserToFirestore(uid, email)
                            }
                        }
                        .addOnFailureListener { e ->
                            Log.e("Firestore", "Error fetching user by email: ${e.message}")
                            showToast("Error fetching user data!")
                        }
                }
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Error fetching user by UID: ${e.message}")
                showToast("Error fetching user data!")
            }
    }

    private fun addUserToFirestore(uid: String, email: String) {
        val userData = hashMapOf(
            "uid" to uid,
            "email" to email,
            "name" to "New User",
            "created_at" to System.currentTimeMillis()
        )

        db.collection("users").document(uid)
            .set(userData)
            .addOnSuccessListener {
                Log.d("Firestore", "User added to Firestore: $uid")
                navigateToHome()
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Error adding user to Firestore: ${e.message}")
                showToast("Error saving user data!")
            }
    }

    private fun navigateToHome() {
        showToast("Login Successful!")
        startActivity(Intent(this, com.example.matrimonialapp.HomeActivity::class.java))
        finish()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
