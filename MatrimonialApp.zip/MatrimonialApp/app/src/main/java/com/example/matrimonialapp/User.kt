package com.example.matrimonialapp

import java.io.Serializable

data class User(
    val userId: String = "",
    val name: String = "",
    val age: Int = 0,
    val gender: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val job: String = "",
    val education: String = "",
    val interests: String = "",
    val contact: String = "",
    val city: String = "",
    val matchScore: Double = 0.0,
    val lastMessage: String = "",
    val timestamp: Long = 0L
) : Serializable

{
    constructor() : this("", "", 0, "", 0.0, 0.0, "", "", "", "", "", 0.0)
}