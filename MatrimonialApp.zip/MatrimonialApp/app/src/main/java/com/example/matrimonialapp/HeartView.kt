package com.example.matrimonialapp.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import com.example.matrimonialapp.R

class HeartView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private val hearts = mutableListOf<Heart>()
    private val paint = Paint()
    private val handler = Handler(Looper.getMainLooper())

    private val heartDrawable: Drawable? = ContextCompat.getDrawable(context, R.drawable.heart1)

    init {
        paint.isAntiAlias = true
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (event?.action == MotionEvent.ACTION_DOWN) {
            addHeart(event.x, event.y)
            return false
        }
        return super.onTouchEvent(event)
    }


    private fun addHeart(x: Float, y: Float) {
        heartDrawable?.let {
            val bitmap = Bitmap.createBitmap(it.intrinsicWidth, it.intrinsicHeight, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            it.setBounds(0, 0, canvas.width, canvas.height)
            it.draw(canvas)

            val heart = Heart(x, y, bitmap, 1f)
            hearts.add(heart)

            animateHeart(heart)

            invalidate()
        }
    }

    private fun animateHeart(heart: Heart) {
        val duration = 1000L
        val frameRate = 16L

        val startTime = System.currentTimeMillis()
        handler.post(object : Runnable {
            override fun run() {
                val elapsed = System.currentTimeMillis() - startTime
                val progress = elapsed.toFloat() / duration

                if (progress >= 1f) {
                    hearts.remove(heart)
                    invalidate()
                    return
                }

                heart.y -= 4
                heart.alpha = 1f - progress

                invalidate()
                handler.postDelayed(this, frameRate)
            }
        })
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (heart in hearts) {
            paint.alpha = (heart.alpha * 255).toInt()
            canvas.drawBitmap(heart.bitmap, heart.x, heart.y, paint)
        }
    }

    private data class Heart(var x: Float, var y: Float, val bitmap: Bitmap, var alpha: Float)
}
