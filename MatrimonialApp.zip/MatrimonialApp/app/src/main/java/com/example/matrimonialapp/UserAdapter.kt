package com.example.matrimonialapp.adapters

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.matrimonialapp.R
import com.example.matrimonialapp.UserModel
import com.example.matrimonialapp.UserProfileDialog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import android.media.MediaPlayer
import com.example.matrimonialapp.utils.HeartView

class UserAdapter(
    private val context: Context,
    private val userList: MutableList<UserModel>,
    private val onNotInterested: (Int) -> Unit
) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_user, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        holder.bind(userList[position])
    }
    override fun getItemCount(): Int = userList.size
    inner class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName: TextView = itemView.findViewById(R.id.tvName)
        private val tvAge: TextView = itemView.findViewById(R.id.tvAge)
        private val tvLocation: TextView = itemView.findViewById(R.id.tvLocation)
        private val tvPhone: TextView = itemView.findViewById(R.id.tvPhone)
        private val btnInterested: Button = itemView.findViewById(R.id.btnInterested)
        private val btnNotInterested: Button = itemView.findViewById(R.id.btnNotInterested)
        fun bind(user: UserModel) {
            tvName.text = user.name
            tvAge.text = "Age: ${user.age}"
            tvLocation.text = "Location: ${user.city ?: "Not Available"}"
            tvPhone.text = "Phone: ${user.contact ?: "Not Available"}"


            btnInterested.setOnClickListener {
                val dialog = UserProfileDialog(context, user)
                dialog.show()
                sendNotification(user.userId, user.name)
            }

            btnNotInterested.setOnClickListener {
                val position =
                    adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    animateRemoval(itemView, position)
                }
            }
        }
        private fun playSnapSound() {
            val mediaPlayer = MediaPlayer.create(context, R.raw.`snap`)
            mediaPlayer.start()
            mediaPlayer.setOnCompletionListener { mp ->
                mp.release()
            }
        }

        private fun sendNotification(receiverUid: String, receiverName: String) {
            val currentUser = FirebaseAuth.getInstance().currentUser
            if (currentUser != null) {
                val senderUid = currentUser.uid
                val senderName = currentUser.displayName ?: "Someone"
                val notificationRef = FirebaseDatabase.getInstance()
                    .getReference("notifications")
                    .child(receiverUid)
                    .push()
                val notificationData = mapOf(
                    "title" to "New Interest!",
                    "message" to "$senderName is interested in you, $receiverName!",
                    "senderUid" to senderUid,
                    "receiverUid" to receiverUid
                )
                notificationRef.setValue(notificationData)
                    .addOnSuccessListener {
                        Toast.makeText(
                            context,
                            "Interest sent to $receiverName!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(context, "Failed to send interest", Toast.LENGTH_SHORT)
                            .show()
                    }
            }
        }

        private fun animateRemoval(view: View, position: Int) {
            val fadeOut = ObjectAnimator.ofFloat(view, "alpha", 1f, 0f).apply { duration = 500 }
            val scatterX = ObjectAnimator.ofFloat(view, "translationX", 0f, (Math.random() * 200 - 100).toFloat()).apply { duration = 500 }
            val scatterY = ObjectAnimator.ofFloat(view, "translationY", 0f, (Math.random() * 200 - 100).toFloat()).apply { duration = 500 }
            val rotate = ObjectAnimator.ofFloat(view, "rotation", 0f, (Math.random() * 360).toFloat()).apply { duration = 500 }
            val shrink = ObjectAnimator.ofFloat(view, "scaleX", 1f, 0f).apply { duration = 500 }
            val animatorSet = AnimatorSet()
            animatorSet.playTogether(fadeOut, scatterX, scatterY, rotate, shrink)
            animatorSet.start()
            animatorSet.addListener(object : Animator.AnimatorListener {
                override fun onAnimationEnd(animation: Animator) {
                    if (position >= 0 && position < userList.size) {
                        userList.removeAt(position)
                        notifyItemRemoved(position)
                        Toast.makeText(context, "Snapped! 🫰", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onAnimationStart(animation: Animator) {
                    playSnapSound()
                }
                override fun onAnimationCancel(animation: Animator) {}
                override fun onAnimationRepeat(animation: Animator) {}
            })
        }
    }
}
