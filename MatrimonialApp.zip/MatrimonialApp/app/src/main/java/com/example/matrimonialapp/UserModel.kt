package com.example.matrimonialapp

data class UserModel(
    var userId: String = "",
    var name: String = "",
    var age: Int = 0,
    var city: String = "",
    var contact: String = ""
) {

    constructor() : this("", "", 0, "", "")
}
