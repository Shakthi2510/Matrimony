package com.example.matrimonialapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.matrimonialapp.utils.HeartView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfileActivity : AppCompatActivity() {

    private lateinit var profileName: TextView
    private lateinit var profileAge: TextView
    private lateinit var profileLocation: TextView
    private lateinit var profileEmail: TextView
    private lateinit var profileGender: TextView
    private lateinit var profileContact: TextView
    private lateinit var btnUpdateProfile: Button

    private val firestore = FirebaseFirestore.getInstance()
    private val userId = FirebaseAuth.getInstance().currentUser?.uid ?: ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        val heartView: HeartView = findViewById(R.id.heartView)
        heartView.bringToFront()

        profileName = findViewById(R.id.profileName)
        profileAge = findViewById(R.id.profileAge)
        profileLocation = findViewById(R.id.profileLocation)
        profileEmail = findViewById(R.id.profileEmail)
        profileGender = findViewById(R.id.profileGender)
        profileContact = findViewById(R.id.profilePhone)
        btnUpdateProfile = findViewById(R.id.btnUpdateProfile)

        if (userId.isNotEmpty()) {
            loadProfileData()
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }


        btnUpdateProfile.setOnClickListener {
            val intent = Intent(this, ExtraDetailsActivity::class.java)
            startActivity(intent)
        }
    }

    private fun loadProfileData() {
        val userRef = firestore.collection("users").document(userId)
        userRef.get().addOnSuccessListener { document ->
            if (document.exists()) {
                profileName.text = document.getString("name") ?: "No Name"
                profileAge.text = "Age: ${document.getLong("age")?.toString() ?: "N/A"}"
                profileLocation.text = "Location: ${document.getString("city") ?: "N/A"}"


                val email = document.getString("email")
                profileEmail.text = if (!email.isNullOrEmpty()) "Email: $email" else "Email: Not Available"

                profileGender.text = "Gender: ${document.getString("gender") ?: "N/A"}"
                profileContact.text = "Contact: ${document.getString("contact") ?: "N/A"}"
            } else {
                Toast.makeText(this, "Profile data not found", Toast.LENGTH_SHORT).show()
            }
        }.addOnFailureListener {
            Toast.makeText(this, "Failed to load profile data", Toast.LENGTH_SHORT).show()
        }
    }
}
