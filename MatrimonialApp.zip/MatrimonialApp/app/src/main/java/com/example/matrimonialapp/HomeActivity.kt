package com.example.matrimonialapp

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.animation.AnimationUtils
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.matrimonialapp.activities.LocationTrackActivity
import com.example.matrimonialapp.adapters.UserAdapter
import com.example.matrimonialapp.databinding.ActivityHomeBinding
import com.example.matrimonyapp.activities.LoginActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.example.matrimonialapp.UserModel
import com.example.matrimonialapp.utils.HeartView

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var userAdapter: UserAdapter
    private val userList = mutableListOf<UserModel>()
    private var userListener: ListenerRegistration? = null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        val heartView: HeartView = findViewById(R.id.heartView)
        heartView.bringToFront()


        userAdapter = UserAdapter(
            this,
            userList,
            ::removeUserWithAnimation
        )



        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = userAdapter

        loadUserProfiles()


        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Matrimonial App"


        findViewById<ImageButton>(R.id.btnHome).setOnClickListener { recreate() }
        findViewById<ImageButton>(R.id.btnHeart).setOnClickListener { navigateTo(GreatMatchActivity::class.java) }
        findViewById<ImageButton>(R.id.btnExtraDetails).setOnClickListener { navigateTo(ExtraDetailsActivity::class.java) }
    }

    private fun navigateTo(destination: Class<*>) {
        startActivity(Intent(this, destination))
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.home_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_location_track -> {
                startActivity(Intent(this, LocationTrackActivity::class.java))
                true
            }
            R.id.action_profile -> {
                startActivity(Intent(this, ProfileActivity::class.java))
                true
            }
                R.id.menu_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    return true
                }
            R.id.action_logout -> {
                auth.signOut()
                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun loadUserProfiles() {
        db.collection("users").get()
            .addOnSuccessListener { result ->
                if (result.isEmpty) {
                    Toast.makeText(this, "No users found in Firestore!", Toast.LENGTH_SHORT).show()
                    return@addOnSuccessListener
                }

                userList.clear()
                for (document in result) {
                    val user = document.toObject(UserModel::class.java)
                    userList.add(user)
                }
                userAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error loading users: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun removeUserWithAnimation(position: Int) {
        if (position in userList.indices) {
            binding.recyclerView.findViewHolderForAdapterPosition(position)?.itemView?.let { itemView ->
                val fadeOut = AnimationUtils.loadAnimation(this, android.R.anim.fade_out)
                itemView.startAnimation(fadeOut)
                itemView.postDelayed({
                    userList.removeAt(position)
                    userAdapter.notifyItemRemoved(position)
                }, 300)
            } ?: run {
                userList.removeAt(position)
                userAdapter.notifyItemRemoved(position)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        userListener?.remove()
    }
}
