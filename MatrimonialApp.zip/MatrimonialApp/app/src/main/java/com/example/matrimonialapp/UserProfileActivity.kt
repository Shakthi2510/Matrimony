package com.example.matrimonialapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.matrimonialapp.utils.HeartView
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.firestore.FirebaseFirestore

class UserProfileActivity : AppCompatActivity() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var db: FirebaseFirestore

    private lateinit var userName: TextView
    private lateinit var userEmail: TextView
    private lateinit var userLocation: TextView
    private lateinit var userAge: TextView
    private lateinit var userCity: TextView
    private lateinit var userContact: TextView
    private lateinit var whatsappButton: Button

    private var favPersonNumber: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_profile)
        val heartView: HeartView = findViewById(R.id.heartView)
        heartView.bringToFront()

        db = FirebaseFirestore.getInstance()

        userName = findViewById(R.id.userName)
        userEmail = findViewById(R.id.userEmail)
        userAge = findViewById(R.id.userAge)
        userCity = findViewById(R.id.userCity)
        userContact = findViewById(R.id.userContact)
        userLocation = findViewById(R.id.userLocation)
        whatsappButton = findViewById(R.id.whatsappButton)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        val selectedUserId = intent.getStringExtra("userId")

        if (selectedUserId != null) {
            fetchUserDetails(selectedUserId)
        } else {
            Toast.makeText(this, "Error: No user ID received", Toast.LENGTH_SHORT).show()
            finish()
        }

        getUserLocation()

        whatsappButton.setOnClickListener {
            favPersonNumber?.let { number ->
                if (number.length >= 10) {
                    openWhatsApp(number)
                } else {
                    Toast.makeText(this, "Wrong number: $number", Toast.LENGTH_SHORT).show()
                }
            } ?: Toast.makeText(this, "No contact number available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun fetchUserDetails(userId: String) {
        db.collection("users").document(userId).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    userName.text = document.getString("name") ?: "No Name Available"
                    userAge.text = "Age: ${document.getLong("age") ?: "N/A"}"
                    userCity.text = "City: ${document.getString("city") ?: "N/A"}"
                    userEmail.text = document.getString("email") ?: "No Email Available"


                    favPersonNumber = document.getString("contact")
                    userContact.text = "Contact: ${favPersonNumber ?: "N/A"}"
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error fetching details", Toast.LENGTH_SHORT).show()
            }
    }

    private fun openWhatsApp(phone: String) {
        try {
            val url = "https://wa.me/$phone"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "WhatsApp not installed or invalid number", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getUserLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
            return
        }

        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                userLocation.text = "Location: ${location.latitude}, ${location.longitude}"
            } else {
                userLocation.text = "Location Not Available"
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getUserLocation()
        } else {
            Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
        }
    }
}
