package com.example.matrimonialapp.ui.theme

import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color

// Light Mode Colors
val LightPrimary = Color(0xFF6D5DD3) // Soft Purple
val LightSecondary = Color(0xFFFFA500) // Warm Orange
val LightTertiary = Color(0xFF57C4E5) // Calm Blue

// Dark Mode Colors
val DarkPrimary = Color(0xFF4A46A3) // Deeper Purple
val DarkSecondary = Color(0xFFD18600) // Dark Orange
val DarkTertiary = Color(0xFF2C9CBD) // Deep Blue

// Light & Dark Color Schemes
val LightColorScheme = lightColorScheme(
    primary = LightPrimary,
    secondary = LightSecondary,
    tertiary = LightTertiary,
    background = Color(0xFFF5F5F5), // Light Gray
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color.Black,
    onSurface = Color.Black
)

val DarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    secondary = DarkSecondary,
    tertiary = DarkTertiary,
    background = Color(0xFF121212), // Dark Background
    surface = Color(0xFF1E1E1E),
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
)
